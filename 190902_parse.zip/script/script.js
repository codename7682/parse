////var a = window.prompt("첫번째 숫자를 입력하세요");
////var b = window.prompt("두번째 숫자를 입력하세요");
////
////a = Number.parseInt(a);
////b = Number.parseInt(b);
////
////var c = a + b;
////alert(c);
////
////var score = new Array();
////score[0] = 85;
////score[1] = 95;
////score[2] = 65;
////score[3] = 67;
////score[4] = 85;
////score[5] = 92;
////score[6] = 16;
////score[7] = 72;
////score[8] = 76;
////score[9] = 82;
////score[10] = 81;
////score[11] = 69;
////score[12] = 72;
////score[13] = 92;
////score[14] = 90;
////score[15] = 68;
////score[16] = 85;
////score[17] = 83;
////
////var sum = 0;
////for(i=0; i<score.length; i++){
////    sum = sum + score[i];
////}
////
////var avg = sum / score.length;
////
////alert("학생 전체 평균 : " + avg);
////
//
//
//
//var height = 110;
//var weight = 121;
//var staff = true;
//
//// 입장할 수 있는 조건
//// 키가 120이상이면서 무게가 120kg이하인 사람.
//// 그런데 staff인 경우에는 상관없이 입장가능.
//
////if(staff){
////    alert("입장 가능");
////}else{
////    if(height >= 120 && weight <= 120){
////        alert("입장 가능");
////    }else{
////        alert("입장 불가능");
////    }
////}
//
////           c+ b0 a- A+  F
//var score = [79,85,92,100,55];
//
//var irum = ['송중기','김태희','궁예','한지호','강다니엘']; 
//var grade = new Array(score.length);
//var grade2 = new Array(score.length);
//
//for(i=0; i<score.length; i++){
//    if(score[i] >= 90){
//        grade[i] = "A";
//    }else if(score[i] >= 80){
//        grade[i] = "B";
//    }else if(score[i] >= 70){
//        grade[i] = "C";
//    }else if(score[i] >= 60){
//        grade[i] = "D";
//    }else{
//        grade[i] = "F";
//    }
//
//    if(score[i] == 100){
//        grade2[i] = "+";
//    }else if(score[i] < 60){
//        grade2[i] = "";
//    }else{
//        var one = score[i] % 10;
//        if(one <= 3){
//            grade2[i] = "-";
//        }else if(one <= 6){
//            grade2[i] = "0";
//        }else{
//            grade2[i] = "+";
//        }
//    }
//    document.write("<p>"+irum[i]+" 학생의 학점은 "+grade[i]+grade2[i]+" 입니다.</p>");
//}
//
//
//
//var age = 19;
//(age >= 20) ? alert("성인") : alert("미성년자");
//
//if(age >= 20){
//    alert("성인");
//}else{
//    alert("미성년자");
//}
//
//
//
//var major = "디자인과";
//
//if(major == "기계과"){
//    alert("당신은 기계과 학생입니다.");
//}else if(major == "전자과"){
//    alert("당신은 전자과 학생입니다.");
//}else{
//    alert("당신은 디자인과 학생입니다.");
//}
//// -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
//if(major == "기계과"){
//    alert("당신은 기계과 학생입니다.");
//}else{
//    if(major == "전자과"){
//        alert("당신은 전자과 학생입니다.");
//    }else{
//        alert("당신은 디자인과 학생입니다.");
//    }
//}
//
//function bodychk(){
//    var btype = window.prompt("당신의 체질을 입력하세요.");
////    switch (btype) {
////        case "태양인" : alert("당신은 태양인 이시군요~");
////            break;
////        case "태음인" : alert("당신은 태음인 이시군요~~");
////            break;
////        case "소양인" : alert("당신은 소양인 이시군요!");
////            break;
////        case "소음인" : alert("당신은 소음인 이시군요~~~");
////            break;
////        default : alert("체질을 정확하게 입력해 주세요");
////            bodychk();
////    }
//    if(btype == "태양인"){
//        alert("당신은 태양인 이시군요");
//    }else if(btype == "태음인"){
//        alert("당신은 태음인 이시군요");
//    }else if(btype == "소양인"){
//        alert("당신은 소양인 이시군요");
//    }else if(btype == "소음인"){
//        alert("당신은 소음인 이시군요");
//    }else{
//        alert("체질을 정확하게 입력해 주세요.");
//        bodychk();
//    }
//}
//
//bodychk();
//
//
//
//var x = "";
////          ↓ 반복할 횟수
//for(i=9; i>=0; i--){
//    x = x + i;
//}
//
//alert(x);
//

//function hello(word){
//    alert(word);
//}
//
//var a = setTimeout(hello,6000,"니하오");
//clearTimeout(a);
//
//function add(){
//    document.getElementById("box").append("ㅋ");
//}
//
//var auto = setInterval(add,100);
//
//document.getElementById("stop").onclick = function(){
//    clearInterval(auto);
//}

//document.getElementsByClassName("apple")[0].style.color = "red";
//
//var apple = document.getElementsByClassName("apple");
//apple[0].style.color = "red";
//
//apple[0].setAttribute("align","right");
//var b = apple[0].getAttribute("align");
//
//apple[0].removeAttribute("align");
//
//var c = apple[0].hasAttribute("class");
//alert(c);
//


//setTimeout(function(){
//    location.reload();
//},5000);


//var max = 10;
//var min = 4;
//var ran = Math.floor(Math.random() * (max-min+1)) + min;

function rand(min, max){
    var result = Math.floor(Math.random()*(max-min+1))+min;
    return result;
}

var box = document.getElementById("box");

var num = 0;
function add(){
    num++;
    var size = rand(50,200);
    box.innerHTML = box.innerHTML + "<div class='b"+num+"'></div>";  
    document.getElementsByClassName("b"+num)[0].style.width = size+"px";
    document.getElementsByClassName("b"+num)[0].style.height = size+"px";
    var w = box.clientWidth;
    var h = box.clientHeight;
    var x = rand(0,w);
    var y = rand(0,h);
    document.getElementsByClassName("b"+num)[0].style.left = x+"px";
    document.getElementsByClassName("b"+num)[0].style.top = y+"px";
}

add();
add();
add();
add();


    
    

    
    
    
    
    
    
    
    






